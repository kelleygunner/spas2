﻿using CielaSpike.Unity.Barcode;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace QrCodeGen
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                DisplayUsage();
                return;
            }

            var content = args[0];
            var path = args[1];
            FileInfo pngFile = null;

            try
            {
                pngFile = new FileInfo(path);
            }
            catch
            {
                Console.WriteLine("Invalid file name: {0}", path);
                return;
            }

            var encoder = Barcode.GetEncoder(BarcodeType.QrCode, new QrCodeEncodeOptions
            {
                Margin = 5,
                Width = 512,
                Height = 512,
                ECLevel = QrCodeErrorCorrectionLevel.M
            });

            var result = encoder.Encode(content);

            if (result.Success)
            {
				var pngData = result.GetPngData();

                using (var pngStream = pngFile.Create())
                {
                    if (!pngStream.CanWrite)
                    {
                        Console.WriteLine("Cannot write target file.");
                        return;
                    }

                    pngStream.Write(pngData, 0, pngData.Length);
                    pngStream.Flush();
                    pngStream.Close();

                    Console.WriteLine("Successfully generate code into");
                    Console.WriteLine(pngFile.FullName);
                }
            }
            else
            {
                Console.WriteLine("Encoding failed: {0}", result.ErrorMessage);
            }
        }

        static void DisplayUsage()
        {
            Console.WriteLine("Usage: qrgen <content> <png-file-path>");
        }
    }
}
